package com.example.emicalculator_2;

public class Constants {
    public static String CURRENCY = "CURRENCY";
    public static String CURRENCY_STORED = "";
    public static boolean LIGHT_THEME = true;
    public static String PACKAGE_NAME = "com.example.emicalculator_2";
}
